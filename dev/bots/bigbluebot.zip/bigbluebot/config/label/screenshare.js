module.exports = {
  share: 'app.actionsBar.actionsDropdown.desktopShareLabel',
  unshare: 'app.actionsBar.actionsDropdown.stopDesktopShareLabel',
  fullscreen: 'app.fullscreenButton.label',
  screenshare: 'app.screenshare.screenShareLabel',
};
