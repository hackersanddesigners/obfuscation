module.exports = {
  // open: 'NOTE OPEN ARIA LABEL',
  open: 'app.note.title',
  close: 'app.note.hideNoteLabel',
  frame: {
    // name: 'NOTE FRAME NAME ARIA LABEL',
    name: 'app.note.label',
    pad: 'NOTE FRAME PAD ARIA LABEL',
  },
};
