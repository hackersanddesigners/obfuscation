module.exports = {
  share: 'app.video.joinVideo',
  unshare: 'app.video.leaveVideo',
  fullscreen: 'app.fullscreenButton.label',
  settings: {
    start: 'app.videoPreview.startSharingLabel',
  },
};
